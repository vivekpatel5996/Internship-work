/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Argusfot.Exercise3.Anagram;
import java.util.*;
/**
 *
 * @author vivek
 */
public class CheckAnagram 
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        
        String string1=sc.nextLine();
        String string2=sc.nextLine();
        
        
        //remove punctuation and whitespace
        string1=string1.replaceAll("[\\s!]*","");
        string2=string2.replaceAll("[\\s!]*","");
        
        CheckAnagram ca=new CheckAnagram();
        //System.out.println(string1+" "+string2);
        boolean result=ca.isAnagram(string1, string2);
        
        if(result)
            System.out.println("Yes.Both are Anagram");
        else
            System.out.println("No.They aren't.");
        
    }
    
    
     boolean isAnagram(String s1,String s2)
    {
	  char first_array[] =s1.toCharArray();
	  char second_array[]=s2.toCharArray();
	  
	  Arrays.sort(first_array);
	  Arrays.sort(second_array);
          
	  String first,second;
	  first=String.valueOf(first_array);
	  second=String.valueOf(second_array);
	  
	   if(first.equals(second))
	   {
		   return true;
	   }
	   else
	   {
		   return false;
	   }
	   
       }
}
