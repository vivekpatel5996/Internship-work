/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Argusfot.Exercise3.CheckPrime;
import java.util.*;
/**
 *
 * @author vivek
 */
public class CheckPrime 
{
    public static void main(String[] args)
    {
        System.out.println("Enter number to check prime or not19");
        Scanner sc=new Scanner(System.in);
        int number=sc.nextInt();
        CheckPrime cp=new CheckPrime();
        boolean result=cp.isPrime(number);
        
        if(result)
            System.out.println("number is  prime");
        else
            System.out.println("number is not prime");
    }
    
    boolean isPrime(int number)
    {
        for(int i=2;i<number;i++)
        {
            if(number%i==0)
                return false;
        }
        
        return true;
    }
}
