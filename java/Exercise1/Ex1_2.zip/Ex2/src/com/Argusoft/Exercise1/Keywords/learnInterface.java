package com.Argusoft.Exercise1.Keywords;

interface i1
{
  
   int var=5;
   void m1();

   static void st()
   {
   	  System.out.println("In static method of interface");
   }
}


interface i2 extends i1
{
	void m2();

	default void def()
	{
		System.out.println("Ohh!! This is new one.");
	}
}


//to check multuiple inheritance
interface i3
{
	void m3();

}


public class learnInterface implements i2,i3
{
	public static void main(String[] args) 
	{
	    learnInterface l1=new learnInterface();
	    l1.m1();
	    l1.m2();

	    l1.def();

	    //for static method of interface
	    i1.st();

	    l1.m3();
	        	
	}

	public void m1()
    {
    	//We can't chabe value because this variable is final in interface
      //	var=6;
		System.out.println("In m1:"+var);
	}


   public void m2()
    {
		System.out.println("In m2:"+var);
	}

    public void m3()
    {
        System.out.println("In m3:");	
    }


}
