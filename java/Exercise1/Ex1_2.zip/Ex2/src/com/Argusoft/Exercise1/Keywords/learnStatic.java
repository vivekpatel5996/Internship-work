package com.Argusoft.Exercise1.Keywords;

class testStatic
{
	static void disp()
	{
		System.out.println("static method without created object");
	}
}


public class learnStatic
{
    static int s=2;
	
	public static void main(String[] args)
	{
		learnStatic l1=new learnStatic();
		l1.s++;
        System.out.println("Using l1,s: "+s);


		learnStatic l2=new learnStatic();
        l2.s++;
        System.out.println("Using l2,s: "+s);


        //calling static method
        testStatic.disp();

	}
}