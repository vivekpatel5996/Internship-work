package com.Argusoft.Exercise1.Keywords;

class test
{
  final int f=5;

  void inc()
  {

  	 //f++;   //throws error  
     System.out.println(f);
  }

  final void override()
  {
  	System.out.println("Can i override final method?");
  }

}

public class learnFinal extends test
{
	//We can't override it
	/*void override()
	{
		System.out.println("Let's check !");
	}*/
	
	public static void main(String[] args)
	{
	
      test a=new test();
      a.inc();
    }


}