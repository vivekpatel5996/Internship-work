package com.Argusoft.Exercise1.Keywords;

abstract class abs 
{
   
   int a=5;

   abstract void disp();

   abs()
   {
   	System.out.println("yeah! I am in constructor of abstract class");
   }

   
   void withBody()
   {
   	 System.out.println("In withBody method");
   }



}

class testing extends abs
{
   
   //This method is compulasory if you extend abs
   void disp()
   {
     System.out.println("In testing disp method");
   }

}



public class learnAbstract extends abs
{

   learnAbstract()
   {
   	super();
   }	

   
   public static void main(String[] args) 
   {
   	    //It thorws error
          //abs a=new abs();

     	learnAbstract la=new learnAbstract();
     	la.disp();
     	la.withBody();
        System.out.println(la.a); 



     	testing t=new testing();
     	t.disp();
     	t.withBody();
   }


   void disp()
   {
   	 System.out.println("Implemented abstract method");
   }
}

