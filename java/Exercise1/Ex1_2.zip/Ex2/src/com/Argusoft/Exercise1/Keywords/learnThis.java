package com.Argusoft.Exercise1.Keywords;

class T
{  
	int n=1;
    
    T()
    {
    	System.out.println("constructor called by this keyword");
    }

    T(int n)
    {
      this();	
      this.n=n;
      System.out.println("In constructor: "+n);
    }
     
   
    void show()
    {
      System.out.println("This is this n"+n);
      this.inA();


    } 


     void inA()
     {
     	System.out.println("Method is called using this");
     }

}

public class learnThis
{   
	public static void main(String[] args) 
	{
	   T a=new T(7);
       a.show();      

	}
}