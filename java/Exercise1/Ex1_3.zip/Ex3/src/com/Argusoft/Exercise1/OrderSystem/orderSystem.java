import java.util.*;

public class orderSystem
{
    
	public static void main(String[] args) 
	{
	   ArrayList<Item> items=new ArrayList<Item>();
           ArrayList<Integer> boughtItems=new ArrayList<Integer>();
           
           setOfItems itemset=new setOfItems();
           items=itemset.getAllItems();
            
           orderSystem ordersystem=new orderSystem();
           ordersystem.printItems(items);
            
           manageOrder manageorder=new manageOrder();
           boughtItems=manageorder.takeOrder(items);
           
           Payment payment=new Payment();
           
           

        }
        
        void printItems(ArrayList<Item> items)
       {
        
        System.out.println("Here your items,Enter id and number of items you want.");

        Iterator itr=items.iterator();  
       
        while(itr.hasNext())
        {   
          Item it=(Item)itr.next();
          System.out.println(it.id+" "+it.name+" "+it.price);  
        } 
       }
}


class Item
{
	int id;
	String name;
	float price;
	Item(int id,String name,float price)
	{
		this.id=id;
		this.price=price;
		this.name=name;
	}
  
}


class setOfItems
{
    ArrayList<Item> items=new ArrayList<Item>();
    
       
    setOfItems()
    {
        items.add(new Item(1,"PC",100));
        items.add(new Item(2,"Speaker",700));
        items.add(new Item(3,"Keybord",600));
        items.add(new Item(4,"Mouse",500));
    }
    
    void addItem()
    {
        
    }
    
    void removeItem()
    {
        
    }
    
    ArrayList<Item> getAllItems()
    {
        return items;
    }
    
}


class manageOrder
{
        
    
    Scanner sc=new Scanner(System.in);
    
    ArrayList<Integer> boughtItems=new ArrayList<Integer>();
    
    ArrayList<Integer> takeOrder(ArrayList<Item> items)
    {
         int itemid=0;
         int quantity=0;
   	 float total_amount=0;
         
         
        System.out.println("Enter -1 as id to stop buying.");
        while(true)
        {

          
          System.out.println("Enter id: ");
          itemid=sc.nextInt();

          if(itemid==-1)
          break;

          System.out.println("Enter quantity: ");
          quantity=sc.nextInt();
          
          Item i=items.get(itemid);
          total_amount=total_amount+(quantity*i.price);
          
         }
         
        System.out.println("Your total amount is: "+total_amount);
        
         return boughtItems; 
    }

}


class Payment
{
    void byCash()
    {
        
    }
    
}