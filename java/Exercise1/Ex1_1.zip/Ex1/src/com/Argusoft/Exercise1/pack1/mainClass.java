/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author vivek
 */


package com.Argusoft.Exercise1.pack1;
//A should be public to use in another package
class A
{
	private int pri_temp=1;
    public int pub_temp=2;
    
    int def_temp=4;
    

    private void priDisplay()
    {
    	System.out.println("In class A itself using temp,value:"+pri_temp);
    }

    public void pubDisplay()
    {
    	System.out.println("In class A itself using temp,value:"+pri_temp);
    }
	


	
}


public class mainClass
{

	protected int pro_temp=3;
	public static void main(String[] args) 
	{
	    A a=new A();
	  

	  //Show error because of using private variable,method of class A
	    //System.out.println(a.pri_temp);	
        //a.pridisplay();
       

       //will Print value because method is public 
        a.pubDisplay();

	}
	
}