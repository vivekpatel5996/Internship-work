/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author vivek
 */
package com.Argusoft.Exercise1.pack2;
import com.Argusoft.Exercise1.pack1.mainClass;


public class mainClass3 extends mainClass
{
   public static void main(String[] args) 
   {
      
         mainClass3 m=new mainClass3();

         System.out.println("Protected varibale in other package pack2 "+m.pro_temp);	
   }
}