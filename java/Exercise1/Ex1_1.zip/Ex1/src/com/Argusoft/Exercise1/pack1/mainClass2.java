/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Argusoft.Exercise1.pack1;

/**
 *
 * @author vivek
 */






public class mainClass2
{
	public static void main(String[] args) 
	{
		 A a1=new A();

		 System.out.println("Default in same package"+a1.def_temp);
	}
}