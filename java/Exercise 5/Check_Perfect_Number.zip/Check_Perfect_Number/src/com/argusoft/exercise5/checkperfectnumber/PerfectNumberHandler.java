/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argusoft.exercise5.checkperfectnumber;
import java.util.*;
/**
 *
 * @author vivek
 */
public class PerfectNumberHandler 
{
    public static void main(String[] args)
    {
        ArrayList<Integer> numbers=new ArrayList<Integer>();
        numbers.add(6);
        numbers.add(10);
        numbers.add(12);
        numbers.add(14);
        numbers.add(19);
        numbers.add(24);
       // CheckPerfectNumber checkPerfectNumber=new CheckPerfectNumber();
        ThreadHandler thread1=new ThreadHandler(numbers);
        ThreadHandler thread2=new ThreadHandler(numbers);
        
        thread1.start();
        thread2.start();
    }
}
