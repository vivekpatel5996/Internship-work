/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argusoft.exercise5.checkperfectnumber;

/**
 *
 * @author vivek
 */
public class CheckPerfectNumber 
{
    synchronized boolean isPerfect(int number)
    {
        int sum=1;
        
        for(int i=2;i<number;i++)
        {
            if(number%i==0)
            {
              sum=sum+i;
            }
        }
        
        if(sum==number)
        {
            System.out.println(number+"  yes");
            return true;
        }
        else
        {
            System.out.println(number+"  no");
            return false;
        }
    }
}
