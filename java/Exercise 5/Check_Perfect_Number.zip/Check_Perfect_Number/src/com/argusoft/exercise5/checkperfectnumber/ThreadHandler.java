/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argusoft.exercise5.checkperfectnumber;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author vivek
 */
public class ThreadHandler extends Thread {

    ArrayList<Integer> numbers = new ArrayList<Integer>();
    static int count;

    public static synchronized void incrementCount() 
    {
       count++;
    }

    CheckPerfectNumber checkPerfectNumber = new CheckPerfectNumber();

    ThreadHandler(ArrayList<Integer> numbers) {
        this.numbers = numbers;
    }

    public void run() {
        System.out.println("here " + this.getId());

        boolean result = false;
         while (count < numbers.size()) 
            {
                int n=0;
                synchronized(checkPerfectNumber)
                {
                    synchronized(numbers)
                    {
                      n=numbers.get(count);
                    }
                    result = checkPerfectNumber.isPerfect(n);
                    incrementCount();
                }
                
                
            }
        

    }

}
