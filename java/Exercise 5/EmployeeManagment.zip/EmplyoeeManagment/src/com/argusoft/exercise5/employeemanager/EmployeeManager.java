/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argusoft.exercise5.employeemanager;
import com.argusoft.exercise5.threadmanagment.ThreadForAdd;
import com.argusoft.exercise5.threadmanagment.ThreadForDelete;
import com.argusoft.exercise5.threadmanagment.ThreadForUpdate;
/**
 *
 * @author vivek
 */
public class EmployeeManager
{
    public static void main(String[] args)
    {
        ThreadForAdd addthread=new ThreadForAdd();
        ThreadForDelete deletethread=new ThreadForDelete();
        ThreadForUpdate updatethread=new ThreadForUpdate();
        
        addthread.start();
        deletethread.start();
        updatethread.start();
    }
}
