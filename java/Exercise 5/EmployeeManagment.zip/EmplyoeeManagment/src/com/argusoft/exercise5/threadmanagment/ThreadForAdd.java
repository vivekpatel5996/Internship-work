/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argusoft.exercise5.threadmanagment;
import com.argusoft.exercise5.employee.Employee;
import com.argusoft.exercise5.employeeoperations.EmployeeService;
import java.util.*;
/**
 *
 * @author vivek
 */
public class ThreadForAdd extends Thread
{
 
    @Override
    public void run()
    {
        
        EmployeeService employeeService=new EmployeeService();
        Employee addEmployee=new Employee();
        addEmployee.setId("1");
        addEmployee.setName("vivek");
        addEmployee.setEmail("vivekjasubhai@gmail.com");
        addEmployee.setContact("9428290425");
        employeeService.createEmployee(addEmployee);
    }
}
