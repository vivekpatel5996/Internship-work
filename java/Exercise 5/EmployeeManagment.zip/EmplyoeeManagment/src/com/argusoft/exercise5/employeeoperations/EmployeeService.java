/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argusoft.exercise5.employeeoperations;
import java.util.*;
import com.argusoft.exercise5.employee.Employee;



/**
 *
 * @author vivek
 */
public class EmployeeService 
{
    ArrayList<Employee> employee_set=new ArrayList<Employee>();
    Iterator<Employee> iterator = employee_set.iterator();
    
    public EmployeeService()
    {
        //this.employee_set=employee_set;
    }
    
    public void createEmployee(Employee employeedata)
    {
      employee_set.add(employeedata);
      System.out.println("Added: "+employee_set);
    }
    
    
    public void updateEmployee(String employeeid,Employee newemployeedata)
    {
       while (iterator.hasNext()) 
        {
           Employee employeedata=iterator.next();
           if(employeedata.getId().equals(employeeid))
           {
               employeedata.setId(newemployeedata.getId());
               employeedata.setName(newemployeedata.getName());
               employeedata.setContact(newemployeedata.getContact());
               employeedata.setEmail(newemployeedata.getEmail());
           }    
	   //System.out.println(iterator.next());
	}
       System.out.println("Updated: "+employee_set);
        
    }
    
   public void deleteEmployee(String employeeid)
    {
      
        
        while (iterator.hasNext()) 
        {
           Employee employee=iterator.next();
           if(employee.getId().equals(employeeid))
           {
               employee_set.remove(employee);
           }    
	   //System.out.println(iterator.next());
	}
      System.out.println("Deleted: "+employee_set);
       
    }
    
    public Employee getEmployee(String employeeid)
    {
       while (iterator.hasNext()) 
        {
           Employee employee=iterator.next();
           if(employee.getId().equals(employeeid))
           {
              return employee;
           }    
	   //System.out.println(iterator.next());
	} 
       
         return null;
    }
    
    public ArrayList<Employee> getEmployees()
    {
        return employee_set;
    }
    
}
