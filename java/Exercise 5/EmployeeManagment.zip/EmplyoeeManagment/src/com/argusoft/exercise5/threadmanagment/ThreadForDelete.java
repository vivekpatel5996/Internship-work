/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argusoft.exercise5.threadmanagment;
import com.argusoft.exercise5.employee.Employee;
import com.argusoft.exercise5.employeeoperations.EmployeeService;
/**
 *
 * @author vivek
 */
public class ThreadForDelete extends Thread
{
     @Override
     public void run()
    {
         EmployeeService employeeService=new EmployeeService();
         employeeService.deleteEmployee("1");
    }    
}
