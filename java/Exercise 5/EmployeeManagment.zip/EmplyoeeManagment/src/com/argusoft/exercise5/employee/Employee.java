/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argusoft.exercise5.employee;

/**
 *
 * @author vivek
 */
public class Employee 
{
    String id;
    String name;
    String email;
    String contact;    

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getContact() {
        return contact;
    }
    
    @Override
    public String toString()
    {
        return "ID: "+this.id+" Name: "+this.name+" Email:"+this.email+" Contact:"+this.contact;
    }
}
