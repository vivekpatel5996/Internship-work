/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argusoft.exercise6.udpclient;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

/**
 *
 * @author vivek
 */
public class UDPClient 
{
   public static void main(String[] args) throws Exception 
    {
        Scanner sc=new Scanner(System.in);
        DatagramSocket datagramSocket=new DatagramSocket();
        while(true)
            
        {
        //To send server
        System.out.print("Enter message:");
        String clientSide=sc.nextLine();
        byte b[]=clientSide.getBytes();
        InetAddress inetAddress=InetAddress.getLocalHost();

        DatagramPacket datagramPacket=new DatagramPacket(b,b.length,inetAddress,9999);
        datagramSocket.send(datagramPacket);
       b=null;
        //To get data
        byte[] buffer=new byte[1024];
        DatagramPacket datafromServer=new DatagramPacket(buffer, buffer.length);
        datagramSocket.receive(datafromServer);
        
        String str=new String(datafromServer.getData());
        
        System.out.println("Receieved: "+str);
        buffer=null;
        }
    }
         
}
