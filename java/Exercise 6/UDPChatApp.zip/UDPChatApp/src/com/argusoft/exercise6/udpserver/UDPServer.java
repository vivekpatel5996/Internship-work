/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argusoft.exercise6.udpserver;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

/**
 *
 * @author vivek
 */
public class UDPServer 
{
     public static void main(String[] args) throws Exception
   {
       Scanner sc=new Scanner(System.in);
       DatagramSocket datagramSocket=new DatagramSocket(9999);
       
       byte buffer[]=new byte[1024];
        //System.out.println("entered");
       
       while(true)
       {
           buffer=new byte[1024];
       DatagramPacket datagramPacket=new DatagramPacket(buffer, buffer.length);
       datagramSocket.receive(datagramPacket);
       String fromClient=new String(datagramPacket.getData());
       
       System.out.println("Received:"+(fromClient));
       buffer=null;
       System.out.print("Enter message:");
       String to_send_client=sc.nextLine();
       InetAddress ia=InetAddress.getLocalHost();
       byte[] toClient=to_send_client.getBytes();
       DatagramPacket dpforclient=new DatagramPacket(toClient, toClient.length,ia,datagramPacket.getPort());
       datagramSocket.send(dpforclient);
       toClient=null;
       }
   }
}
