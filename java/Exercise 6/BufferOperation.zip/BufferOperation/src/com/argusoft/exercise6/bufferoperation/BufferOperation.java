/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argusoft.exercise6.bufferoperation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author vivek
 */
public class BufferOperation 
{
      static char bufferedData[]=new char[10];
      static int front=0,end=0;
      
        static void getDataFromUser() throws IOException
        {
          InputStreamReader inputStreamReader =new InputStreamReader(System.in);
          BufferedReader bufferedReader=new BufferedReader(inputStreamReader);
         
          char char_from_user;
          boolean  should_front_increment=false;
                  
          System.out.println("Enter @ to stop entering input");
         
          do
          {
             char_from_user=(char)bufferedReader.read();
             if(char_from_user!='@')
             {
              
                 bufferedData[end%10]=char_from_user;
                 end++;
                 if(end==10)
                     end=0;
             }
             
          }
          while(char_from_user!='@');
        }
      
        static void retrieveFromBuffer()
        {
            int start_to_print=end;
            int end_to_print=end-1;
            System.out.println("Your last 100 characters:");
            
            while(start_to_print!=end_to_print)
            { 
              System.out.print(bufferedData[start_to_print%10]);
              start_to_print++;
                if(start_to_print==10)
                    start_to_print=0;
            }
            
            System.out.println(bufferedData[start_to_print]);
        }
}
