/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argusoft.exercise6.bufferoperation;
import java.util.*;
import java.io.*;
/**
 *
 * @author vivek
 */
public class BufferManager 
{
     public static void main(String[] args) throws IOException
     {
         Scanner sc=new Scanner(System.in);
         System.out.println("Enter 1 to take from user\n Enter 2 to retrieve last"
                 + " 100 char\n Enter 99 to stop app");
         
         
         int choice=0;
         
         do
         {
            choice=sc.nextInt();
            switch(choice)
            {
             
              case 1: 
                     BufferOperation.getDataFromUser();
                     break;
             
              case 2:
                     BufferOperation.retrieveFromBuffer();
                     break;
                     
              case 99:
                     break; 
                 
                     
              default:
                      System.out.println("Choice option which are available");
                     
            }
            
         }
         while(choice!=99);
        
         System.out.println("End");
     }
}
