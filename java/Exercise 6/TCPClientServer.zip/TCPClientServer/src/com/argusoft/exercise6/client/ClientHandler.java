/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argusoft.exercise6.client;

import java.io.*;
import java.net.*;
import java.util.Scanner;
import sun.awt.X11.XConstants;

/**
 *
 * @author vivek
 */
public class ClientHandler {

    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);

        String ip = "localhost";
        int port = 9999;

        Socket socket = new Socket("localhost", 9999);

        System.out.println("Enter string to reverse: ");
        String user_input = sc.nextLine();

        //to convert into stream 
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(socket.getOutputStream());
        //to send data to server
        PrintWriter printWriter = new PrintWriter(outputStreamWriter);
        printWriter.println(user_input);
        printWriter.flush();

        //Revsersed string from server
        BufferedReader bufferedReader
                = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        String reversedString = bufferedReader.readLine();

        System.out.println("Reversed String: " + reversedString);
//      

    }
}
