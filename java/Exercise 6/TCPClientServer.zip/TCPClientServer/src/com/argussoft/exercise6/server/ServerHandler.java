/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argussoft.exercise6.server;
import java.io.*;
import java.net.*;

/**
 *
 * @author vivek
 */
public class ServerHandler 
{
 public static void main(String[] args) throws IOException 
 {
     ServerSocket serverSocket=new ServerSocket(9999);
     
     //Wait for client request
     Socket socket=serverSocket.accept();
     
     System.out.println("Connected");
     
     BufferedReader bufferedReader=
             new BufferedReader(new InputStreamReader(socket.getInputStream()));
  
     String from_client=bufferedReader.readLine();
     
     System.out.println("From client: "+from_client);
     
     //reverse a string
     StringBuffer sb=new StringBuffer(from_client);
     sb.reverse();
     System.out.println(sb.toString());
     
     //Send reversed string to client
     OutputStreamWriter outputStreamWriter=new OutputStreamWriter(socket.getOutputStream());
      //to send data to server
      PrintWriter printWriter=new PrintWriter(outputStreamWriter);
      printWriter.println(sb.toString());
      printWriter.flush();
//     
     
      
      
     
 }
}    

