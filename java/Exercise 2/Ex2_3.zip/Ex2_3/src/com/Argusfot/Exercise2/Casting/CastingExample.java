/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Argusfot.Exercise2.Casting;

/**
 *
 * @author vivek
 */
public class CastingExample 
{
   public static void main(String[] args)   
   {
         //implicit
         int lowerSize=12213;
         double higherSize=0;
         
         higherSize=lowerSize;
         
         System.out.println(higherSize);
         
         //Explicit
         float a=12.5f;
         int b=0;
         b=(int)a;
         System.out.println(b);
         
         
         
   }
}
