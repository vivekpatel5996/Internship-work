/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Argusfot.Exercise2.Autoboxing;

/**
 *
 * @author vivek
 */
public class AutoboxingExample 
{
  public static void main(String[] args)
  {
      
       //autoboxing
       int primitive=5;
       Integer wrapper=primitive;
       
       System.out.println(wrapper);
       
       //unboxing
       
       Character wrapper_ch=new Character('a');
       
       char primitive_ch=wrapper_ch;
       
       System.out.println(primitive_ch);
       
       
  }
}
