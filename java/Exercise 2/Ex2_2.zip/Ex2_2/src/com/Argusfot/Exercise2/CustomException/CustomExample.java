/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Argusfot.Exercise2.CustomException;

/**
 *
 * @author vivek
 */
import java.util.*;
class CustomException extends Exception
{
    CustomException(String s)
    {
        super(s);
    }
}
public class CustomExample 
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        String auth_user="vivek";
        
        
       
        System.out.println("Enter user name:");
        String user_input=sc.nextLine(); 
        
        if(user_input.equals(auth_user))
        {
            System.out.println("Welcome! vivek patel");
        }
        else
        {
            try
            {
                throw new CustomException("You are not authorized user");
            }
            catch(CustomException e)
            {
                System.out.println(e);
            }
            
        }
        
    }
}
