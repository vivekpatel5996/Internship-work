/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Argusfot.Exercise2.CompileTimeException;
import java.io.*;
/**
 *
 * @author vivek
 */

class Parent
{
    //Should add 'throws' for compile time
    void msg() throws IOException  
    {
        throw new IOException("IO exception");
    }
    
    
}
public class CompiletimeExample
{
    public static void main(String[] args)
    {
        Parent p=new Parent();
        
        //It must be caught here
        try
        {
          p.msg();
        }
        catch(IOException e)
        {
            System.out.println("It's IOExcpetion: "+e);
        }
    }
}
