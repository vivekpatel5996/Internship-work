/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Argusfot.Exercise2.RuntimeException;

import java.io.IOException;

/**
 *
 * @author vivek
 */
class Parent
{
    //Should not add 'throws' for runtime
    void msg() 
    {
        throw new NullPointerException("Null pointer exception");
    }
    

}


public class RuntimeExample extends Parent
{
    public static void main(String[] args)
    {
        
        Parent p=new Parent();
        
        //Runtime so it is handled by main handler
        p.msg();
        
        try
        {
            int a=10/0;  
        }    
        catch(ArithmeticException e)
        {
           System.out.println("Divided by Zero is not possible: "+e);
        }
    }
    
}
