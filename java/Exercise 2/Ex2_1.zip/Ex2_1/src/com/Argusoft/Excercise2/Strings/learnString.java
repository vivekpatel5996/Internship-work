/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Argusoft.Excercise2.Strings;
import  java.util.*;


/**
 *
 * @author VIVEK
 */
public class learnString 
{
     public static void main(String[] args)
     {
             
      String firstObject="string";
      
      //It will create new object 
      firstObject.concat("concatation");
      System.out.println(firstObject);
      
      
      //new object is created and reference given to newObject
      String newObject=firstObject.concat("  concatation");;
      System.out.println(newObject);
      
      //String comparision
      
      //using equals() method
      
      String s1="using equals() method";
      String s2="using equals() method";
      
      String s3=new String("using equals() method");
      
      //All three object have same string
      System.out.println(s1.equals(s2));
      System.out.println(s1.equals(s3));    
      
      //In string pool only one string,both object reference to the same
      System.out.println(s1==s2);
      
      //Both object are not referenced by same variable
      System.out.println(s1==s3);
      
      String str1="abcd";
      String str2="dfb";
      
      System.out.println(str1.compareTo(str2));
      System.out.println(str2.compareTo(str1));
      
      //substring
       System.out.println(s1.substring(6));
       System.out.println(s1.substring(0,5));
       System.out.println(s1.substring(2,8));
      
     }
    
}
