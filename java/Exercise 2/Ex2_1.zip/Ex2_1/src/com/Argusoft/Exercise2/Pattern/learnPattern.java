/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.Argusoft.Exercise2.Pattern;
import java.util.regex.*;
/**
 *
 * @author vivek
 */
public class learnPattern 
{
     public static void main(String[] args)
     {
         Pattern p=Pattern.compile("[a-zA-Z]*");
         Matcher m=p.matcher("agfxcgfcAA");
         boolean check=m.matches();
         System.out.println(check);
         
         
         boolean simple_way=Pattern.matches("[a-zA-Z]","dfhb213A");
         System.out.println(simple_way);
     }
}
