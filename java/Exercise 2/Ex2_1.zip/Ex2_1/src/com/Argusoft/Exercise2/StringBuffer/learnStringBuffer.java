/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Argusoft.Exercise2.StringBuffer;

/**
 *
 * @author vivek
 */
public class learnStringBuffer 
{
    public static void main(String[] args)
    {
        StringBuffer s1=new StringBuffer("first string");
        StringBuffer s2=new StringBuffer("second string");
        StringBuffer s3=new StringBuffer("reverse testing");
        
        //length and capacity
         System.out.println("length:"+s1.length());
         
         //capacity is length+16
         System.out.println("capacity:"+s1.capacity());
         
         
         //insert 
         
         s1.insert(6,"inserterd");
         
         System.out.println("After inserted: "+s1);
         
         //reverse
         
         s3.reverse();
         
         System.out.println("Reversed string:" +s3);
         
         //delete  deleteCharAt
         
         s1.delete(6, 15);
         System.out.println("After deleting: "+s1);
         
         //remove space in s3 string using deleteCharAt

         s3.deleteCharAt(7);
         System.out.println("using deleteCharAt(): "+s3);
         
         //append
         
         s1.append(s2);
         System.out.println("appended string: "+s1);
         
         
                 
         
       
    }
}
