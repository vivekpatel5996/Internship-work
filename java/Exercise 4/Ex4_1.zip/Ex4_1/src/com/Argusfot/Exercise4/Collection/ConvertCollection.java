/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Argusfot.Exercise4.Collection;
import java.util.*;
/**
 *
 * @author vivek
 */
public class ConvertCollection 
{
     public static void main(String[] args)
     {
        Scanner sc=new Scanner(System.in);
         System.out.println("Enter number of strings");
         
         int total_strings=sc.nextInt();
         
         sc.nextLine();
         
         String[] strings=new String[total_strings];
        
         for(int i=0;i<strings.length;i++)
         {
             strings[i]=sc.nextLine();
         }
         
         Converter c=new Converter();
         
         //ArrayList
         System.out.println("\n-------------Operations on ArrayList------------\n");
         
         ArrayList<String> arraylist=c.arrayToArrayList(strings);
         System.out.println("converted Array to ArrayList: "+arraylist);
         
         arraylist.add("added to al");
         System.out.println("After added: "+arraylist);
         
         System.out.println("Retrieved value: "+arraylist.get(2));
         
         
         arraylist.remove(1);
         System.out.println("After removed 2nd: "+arraylist);
         
         
         //set
         System.out.println("\n-------------Operations on Set------------\n");
         
         Set<String> set=c.arraylistToSet(arraylist);
         System.out.println("converted ArrayList to Set: "+set);
        
         
         set.add("added to set");
         System.out.println("After added: "+set);
         
         set.remove("vivek");
         System.out.println("After deleted 'vivek'"+set);
         
         
         //TreeSet
          System.out.println("\n-------------Operations on TreeSet------------\n");
          TreeSet<String> treeset=c.setToTreeset(set);
          System.out.println("converted Set to TreeSet: "+treeset);
          
          treeset.add("AAA");
          System.out.println("After added:"+treeset);
          
          treeset.remove("AAA");
          System.out.println("After deleted:  "+treeset);
         
     }
             
}


class Converter
{
    ArrayList<String>  arrayToArrayList(String[] arr)
    {
        ArrayList<String> al=new ArrayList<String>(Arrays.asList(arr));
        return al;
    }
    
    Set<String> arraylistToSet(ArrayList<String> al)
    {
        Set<String> set=new HashSet<String>(al);
        return set;
    }
    
    TreeSet<String> setToTreeset(Set<String> set)
    {
        TreeSet<String> treeset=new TreeSet<String>(set);
        
        return treeset;
    }
    
}