/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Argusfot.Exercise4.CharacterCounter;
import java.util.*;
/**
 *
 * @author vivek
 */



public class CharCounter 
{ 
    
   public static void main(String[] args)
   {
       Scanner sc=new Scanner(System.in);
       CharCounter cc=new CharCounter();
       
      
       HashMap<String,HashMap<Character,Integer>> cache=new  HashMap<String,HashMap<Character,Integer>>();
       System.out.println("Enter string");
       String user_input=sc.nextLine();
       do
       {
           
        if(!cache.containsKey(user_input))
        {
           System.out.println("Enter counter:"+java.time.LocalTime.now());   
           HashMap<Character,Integer> counter_result=cc.counter(user_input);
           cache.put(user_input,counter_result);
           System.out.println("Exit counter:"+java.time.LocalTime.now());   
        }
          System.out.println("Your character counter result: "+cache.get(user_input));
          System.out.println("Enter string");
          user_input=sc.nextLine();
        }
        while(!user_input.equals("-1"));
       
   }
   
   HashMap<Character,Integer> counter(String input)
   {
       HashMap<Character,Integer> char_counter=new HashMap<Character,Integer>();
       
       for(int i=0;i<input.length();i++)
       {
           if(char_counter.containsKey(input.charAt(i)))
           {
               int value=char_counter.get(input.charAt(i));
               value++;
               char_counter.put(input.charAt(i),value);
           }
           else
           {
               char_counter.put(input.charAt(i),1);
           }
       }
       
       return char_counter;
   }
   
}
