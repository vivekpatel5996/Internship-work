/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.argusoft.textdecoration;

import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.*;
import java.io.*;
import static javax.servlet.jsp.tagext.Tag.*;


/**
 *
 * @author vivek
 */
public class TextDecoratorTagHandler extends SimpleTagSupport {

    /**
     * Called by the container to invoke this tag. The implementation of this
     * method is provided by the tag library developer, and handles all tag
     * processing, body iteration, etc.
     */
 
    public  void doTag() throws JspException {
        JspWriter out = getJspContext().getOut();
        
        try {
           
             StringWriter sw = new StringWriter();
             getJspBody().invoke(sw);
             out.println("<h1 style='color:red'><b><blink>"+sw.toString()+"</blink></b1></h1>");
            
            /*JspFragment f = getJspBody();
            if (f != null) {
                f.invoke(out);
            }*/

           
        } catch (java.io.IOException ex) {
            throw new JspException("Error in TextDecoratorTagHandler tag", ex);
        }
       
    }
    
    
}
